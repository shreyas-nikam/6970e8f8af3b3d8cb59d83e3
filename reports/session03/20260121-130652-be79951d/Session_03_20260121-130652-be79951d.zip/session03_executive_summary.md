# Enterprise AI Model Risk Tiering Summary - Run 20260121-130521-e97c3af7

**Date:** 2026-01-21 13:06:52

This report provides a snapshot of the enterprise AI model inventory and their assigned risk tiers, based on the automated tiering framework.

## Model Inventory Overview

| model_id                             | model_name                   |   risk_score | risk_tier   | created_at                 | tiering_timestamp          |
|:-------------------------------------|:-----------------------------|-------------:|:------------|:---------------------------|:---------------------------|
| c3d098a3-f24f-487b-9c4d-73926d8fd7c7 | Predictive Maintenance Model |           31 | Tier 1      | 2026-01-21T13:05:21.432128 | 2026-01-21T13:05:21.435241 |
| 8a779e56-23d8-4c67-bd0d-f752101cb651 | LLM Compliance Assistant     |           45 | Tier 1      | 2026-01-21T13:05:21.426002 | 2026-01-21T13:05:21.429173 |
| 52172413-f8e8-453b-abcd-b6c7c0503d37 | Credit Risk Scoring Model    |           79 | Tier 1      | 2026-01-21T13:05:21.418328 | 2026-01-21T13:05:21.421104 |
| 550e313d-32dd-429a-97bd-c6ac5ad40514 | Credit Risk Scoring Model    |          nan |             | 2026-01-21T13:05:21.415177 |                            |
| 89700f91-4370-4747-bd40-751269a92ac8 | Predictive Maintenance Model |           31 | Tier 1      | 2026-01-21T13:04:42.804711 | 2026-01-21T13:04:42.808476 |
| 9c314190-53d5-4dea-9d43-ef503b5cb04d | LLM Compliance Assistant     |           45 | Tier 1      | 2026-01-21T13:04:42.799274 | 2026-01-21T13:04:42.802214 |
| 6c4b0a07-7da9-446c-a0c1-a6d57e7da050 | Credit Risk Scoring Model    |           79 | Tier 1      | 2026-01-21T13:04:42.791749 | 2026-01-21T13:04:42.794456 |
| 0b9fb13b-6f35-426d-b29f-4fae4df238ea | Credit Risk Scoring Model    |          nan |             | 2026-01-21T13:04:42.788332 |                            |
| 71be6330-26a8-4faf-a4d4-16d1e367b676 | Predictive Maintenance Model |           31 | Tier 1      | 2026-01-21T13:03:10.295418 | 2026-01-21T13:03:10.299525 |
| 2c475388-fec0-418e-aac0-0dd3f7b531e3 | LLM Compliance Assistant     |           45 | Tier 1      | 2026-01-21T13:03:10.289251 | 2026-01-21T13:03:10.291745 |
| 4ff42e1d-3ac5-40d9-991f-08c17459faa0 | Credit Risk Scoring Model    |           79 | Tier 1      | 2026-01-21T13:03:10.282994 | 2026-01-21T13:03:10.285712 |
| d62bd86e-15e4-4550-a3a8-bb4e12786624 | Credit Risk Scoring Model    |          nan |             | 2026-01-21T13:03:10.280105 |                            |

## Key Observations

- Total Models Onboarded: 12
- Models in Tier 1: 9

This summary confirms the effective application of our risk tiering framework, ensuring all new models are appropriately classified for governance and control allocation.
